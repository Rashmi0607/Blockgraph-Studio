# Backend

FastAPI backend for the pipeline editor.

## Setup

```bash
cd backend
pip install -r requirements.txt
```

## Run

```bash
uvicorn main:app --reload
```

The API will be available at `http://localhost:8000`

## Endpoints

- `GET /` - Health check
- `POST /pipelines/parse` - Parse pipeline and validate DAG
  - Request body: `{nodes: [...], edges: [...]}`
  - Response: `{num_nodes: int, num_edges: int, is_dag: bool}`
