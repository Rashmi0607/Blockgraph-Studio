export type NodeType = 'input' | 'output' | 'text' | 'llm' | 'transform' | 'filter' | 'aggregate';

export interface NodeData {
  label: string;
  content?: string;
  variables?: string[];
}

export interface PipelineNode {
  id: string;
  type: NodeType;
  position: { x: number; y: number };
  data: NodeData;
}

export interface PipelineEdge {
  id: string;
  source: string;
  target: string;
  sourceHandle?: string;
  targetHandle?: string;
}

export interface PipelineValidation {
  num_nodes: number;
  num_edges: number;
  is_dag: boolean;
}
