import { memo } from 'react';
import { NodeProps } from 'reactflow';
import { Database } from 'lucide-react';
import BaseNode from './BaseNode';

const InputNode = memo((props: NodeProps) => {
  return (
    <BaseNode
      {...props}
      icon={<Database className="w-4 h-4" />}
      color="bg-card border-node-input"
      hasInput={false}
      hasOutput={true}
    />
  );
});

InputNode.displayName = 'InputNode';

export default InputNode;
