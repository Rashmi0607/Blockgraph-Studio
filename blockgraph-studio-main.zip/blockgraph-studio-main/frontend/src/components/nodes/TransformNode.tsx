import { memo } from 'react';
import { NodeProps } from 'reactflow';
import { Wand2 } from 'lucide-react';
import BaseNode from './BaseNode';

const TransformNode = memo((props: NodeProps) => {
  return (
    <BaseNode
      {...props}
      icon={<Wand2 className="w-4 h-4" />}
      color="bg-card border-node-transform"
      hasInput={true}
      hasOutput={true}
    />
  );
});

TransformNode.displayName = 'TransformNode';

export default TransformNode;
