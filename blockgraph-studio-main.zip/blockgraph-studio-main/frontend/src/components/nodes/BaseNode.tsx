import { memo } from 'react';
import { Handle, Position, NodeProps } from 'reactflow';
import { cn } from '@/lib/utils';

export interface BaseNodeProps extends NodeProps {
  icon: React.ReactNode;
  color: string;
  hasInput?: boolean;
  hasOutput?: boolean;
  inputHandles?: string[];
  outputHandles?: string[];
}

const BaseNode = memo(({ 
  data, 
  icon, 
  color, 
  hasInput = true, 
  hasOutput = true,
  inputHandles = [],
  outputHandles = [],
}: BaseNodeProps) => {
  const showDefaultInput = hasInput && inputHandles.length === 0;
  const showDefaultOutput = hasOutput && outputHandles.length === 0;

  return (
    <div className={cn(
      "relative rounded-lg shadow-node border-2 transition-all",
      "hover:shadow-glow min-w-[180px]",
      color
    )}>
      {/* Input Handles */}
      {showDefaultInput && (
        <Handle 
          type="target" 
          position={Position.Left} 
          className="!w-3 !h-3 !bg-primary"
        />
      )}
      {inputHandles.map((handleId, index) => (
        <Handle
          key={handleId}
          type="target"
          position={Position.Left}
          id={handleId}
          className="!w-3 !h-3 !bg-primary"
          style={{ top: `${30 + (index * 25)}%` }}
        />
      ))}

      {/* Node Content */}
      <div className="px-4 py-3">
        <div className="flex items-center gap-2 mb-2">
          <div className="text-foreground">{icon}</div>
          <div className="font-semibold text-sm text-foreground">{data.label}</div>
        </div>
        {data.content && (
          <div className="text-xs text-muted-foreground mt-2 break-words">
            {data.content}
          </div>
        )}
      </div>

      {/* Output Handles */}
      {showDefaultOutput && (
        <Handle 
          type="source" 
          position={Position.Right} 
          className="!w-3 !h-3 !bg-primary"
        />
      )}
      {outputHandles.map((handleId, index) => (
        <Handle
          key={handleId}
          type="source"
          position={Position.Right}
          id={handleId}
          className="!w-3 !h-3 !bg-primary"
          style={{ top: `${30 + (index * 25)}%` }}
        />
      ))}
    </div>
  );
});

BaseNode.displayName = 'BaseNode';

export default BaseNode;
