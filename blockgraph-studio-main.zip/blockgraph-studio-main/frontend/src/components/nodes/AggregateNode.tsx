import { memo } from 'react';
import { NodeProps } from 'reactflow';
import { Layers } from 'lucide-react';
import BaseNode from './BaseNode';

const AggregateNode = memo((props: NodeProps) => {
  return (
    <BaseNode
      {...props}
      icon={<Layers className="w-4 h-4" />}
      color="bg-card border-node-aggregate"
      hasInput={true}
      hasOutput={true}
    />
  );
});

AggregateNode.displayName = 'AggregateNode';

export default AggregateNode;
