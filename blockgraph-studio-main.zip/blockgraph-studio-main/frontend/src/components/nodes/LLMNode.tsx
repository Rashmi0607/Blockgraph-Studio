import { memo } from 'react';
import { NodeProps } from 'reactflow';
import { Brain } from 'lucide-react';
import BaseNode from './BaseNode';

const LLMNode = memo((props: NodeProps) => {
  return (
    <BaseNode
      {...props}
      icon={<Brain className="w-4 h-4" />}
      color="bg-card border-node-llm"
      hasInput={true}
      hasOutput={true}
    />
  );
});

LLMNode.displayName = 'LLMNode';

export default LLMNode;
