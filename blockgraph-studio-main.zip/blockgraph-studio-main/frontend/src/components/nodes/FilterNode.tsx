import { memo } from 'react';
import { NodeProps } from 'reactflow';
import { Filter } from 'lucide-react';
import BaseNode from './BaseNode';

const FilterNode = memo((props: NodeProps) => {
  return (
    <BaseNode
      {...props}
      icon={<Filter className="w-4 h-4" />}
      color="bg-card border-node-filter"
      hasInput={true}
      hasOutput={true}
    />
  );
});

FilterNode.displayName = 'FilterNode';

export default FilterNode;
