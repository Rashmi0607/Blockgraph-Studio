import { memo, useState, useEffect, useRef } from 'react';
import { NodeProps } from 'reactflow';
import { Type } from 'lucide-react';
import BaseNode from './BaseNode';

const TextNode = memo((props: NodeProps) => {
  const [text, setText] = useState(props.data.content || '');
  const [variables, setVariables] = useState<string[]>([]);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    // Extract {{variable}} patterns
    const regex = /\{\{(\w+)\}\}/g;
    const matches = text.matchAll(regex);
    const vars = Array.from(matches, m => m[1]);
    const uniqueVars = [...new Set(vars)];
    setVariables(uniqueVars);
    
    // Update node data
    props.data.content = text;
    props.data.variables = uniqueVars;
  }, [text, props.data]);

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = textareaRef.current.scrollHeight + 'px';
    }
  }, [text]);

  return (
    <div className="relative">
      <BaseNode
        {...props}
        icon={<Type className="w-4 h-4" />}
        color="bg-card border-node-text"
        hasInput={true}
        hasOutput={true}
        inputHandles={variables}
      />
      <div className="absolute top-full left-0 w-full mt-2 z-10">
        <textarea
          ref={textareaRef}
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Enter text with {{variables}}..."
          className="w-full px-3 py-2 bg-card border border-border rounded-lg text-sm text-foreground resize-none min-h-[60px] focus:outline-none focus:ring-2 focus:ring-primary"
        />
        {variables.length > 0 && (
          <div className="mt-1 text-xs text-muted-foreground">
            Variables: {variables.join(', ')}
          </div>
        )}
      </div>
    </div>
  );
});

TextNode.displayName = 'TextNode';

export default TextNode;
