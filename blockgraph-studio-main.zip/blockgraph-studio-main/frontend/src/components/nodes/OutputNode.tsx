import { memo } from 'react';
import { NodeProps } from 'reactflow';
import { Save } from 'lucide-react';
import BaseNode from './BaseNode';

const OutputNode = memo((props: NodeProps) => {
  return (
    <BaseNode
      {...props}
      icon={<Save className="w-4 h-4" />}
      color="bg-card border-node-output"
      hasInput={true}
      hasOutput={false}
    />
  );
});

OutputNode.displayName = 'OutputNode';

export default OutputNode;
