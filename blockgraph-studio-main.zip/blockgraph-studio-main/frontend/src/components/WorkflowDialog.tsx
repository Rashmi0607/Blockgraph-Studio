import { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from './ui/dialog';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { ScrollArea } from './ui/scroll-area';
import { Trash2, FileDown } from 'lucide-react';

interface Workflow {
  id: string;
  name: string;
  nodes: any[];
  edges: any[];
  timestamp: number;
}

interface WorkflowDialogProps {
  isOpen: boolean;
  onClose: () => void;
  mode: 'save' | 'load';
  currentNodes: any[];
  currentEdges: any[];
  onLoad: (nodes: any[], edges: any[]) => void;
}

const WorkflowDialog = ({ 
  isOpen, 
  onClose, 
  mode,
  currentNodes,
  currentEdges,
  onLoad 
}: WorkflowDialogProps) => {
  const [workflowName, setWorkflowName] = useState('');
  const [savedWorkflows, setSavedWorkflows] = useState<Workflow[]>([]);

  useEffect(() => {
    loadSavedWorkflows();
  }, [isOpen]);

  const loadSavedWorkflows = () => {
    const saved = localStorage.getItem('workflows');
    if (saved) {
      setSavedWorkflows(JSON.parse(saved));
    }
  };

  const handleSave = () => {
    if (!workflowName.trim()) {
      alert('Please enter a workflow name');
      return;
    }

    const workflow: Workflow = {
      id: Date.now().toString(),
      name: workflowName,
      nodes: currentNodes,
      edges: currentEdges,
      timestamp: Date.now(),
    };

    const existing = savedWorkflows.filter(w => w.name !== workflowName);
    const updated = [...existing, workflow];
    
    localStorage.setItem('workflows', JSON.stringify(updated));
    setSavedWorkflows(updated);
    setWorkflowName('');
    alert('Workflow saved successfully!');
    onClose();
  };

  const handleLoad = (workflow: Workflow) => {
    onLoad(workflow.nodes, workflow.edges);
    onClose();
  };

  const handleDelete = (id: string) => {
    const updated = savedWorkflows.filter(w => w.id !== id);
    localStorage.setItem('workflows', JSON.stringify(updated));
    setSavedWorkflows(updated);
  };

  const handleExport = (workflow: Workflow) => {
    const dataStr = JSON.stringify(workflow, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    const exportFileDefaultName = `${workflow.name}.json`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[525px]">
        <DialogHeader>
          <DialogTitle>
            {mode === 'save' ? 'Save Workflow' : 'Load Workflow'}
          </DialogTitle>
          <DialogDescription>
            {mode === 'save' 
              ? 'Enter a name to save your current workflow' 
              : 'Select a workflow to load'}
          </DialogDescription>
        </DialogHeader>

        {mode === 'save' ? (
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="name">Workflow Name</Label>
              <Input
                id="name"
                value={workflowName}
                onChange={(e) => setWorkflowName(e.target.value)}
                placeholder="Enter workflow name"
              />
            </div>
            <Button onClick={handleSave}>
              Save Workflow
            </Button>
          </div>
        ) : (
          <ScrollArea className="h-[400px] pr-4">
            {savedWorkflows.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                No saved workflows found
              </div>
            ) : (
              <div className="space-y-2">
                {savedWorkflows.map((workflow) => (
                  <div
                    key={workflow.id}
                    className="flex items-center justify-between p-3 border rounded-lg hover:bg-muted/50"
                  >
                    <div className="flex-1">
                      <div className="font-medium">{workflow.name}</div>
                      <div className="text-xs text-muted-foreground">
                        {workflow.nodes.length} nodes, {workflow.edges.length} edges
                        {' • '}
                        {new Date(workflow.timestamp).toLocaleDateString()}
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleExport(workflow)}
                        title="Export workflow"
                      >
                        <FileDown className="w-4 h-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleDelete(workflow.id)}
                        title="Delete workflow"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                      <Button
                        size="sm"
                        onClick={() => handleLoad(workflow)}
                      >
                        Load
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </ScrollArea>
        )}
      </DialogContent>
    </Dialog>
  );
};

export default WorkflowDialog;
