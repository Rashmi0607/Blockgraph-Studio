import { useCallback, useState } from 'react';
import ReactFlow, {
  Background,
  Controls,
  MiniMap,
  addEdge,
  Connection,
  Edge,
  Node,
  useNodesState,
  useEdgesState,
  NodeMouseHandler,
} from 'reactflow';
import 'reactflow/dist/style.css';

import InputNode from './nodes/InputNode';
import OutputNode from './nodes/OutputNode';
import TextNode from './nodes/TextNode';
import LLMNode from './nodes/LLMNode';
import TransformNode from './nodes/TransformNode';
import FilterNode from './nodes/FilterNode';
import AggregateNode from './nodes/AggregateNode';
import Toolbar from './Toolbar';
import NodeConfigDialog from './NodeConfigDialog';
import WorkflowDialog from './WorkflowDialog';
import { useToast } from '@/hooks/use-toast';
import { submitPipeline } from '../submit';

const nodeTypes = {
  input: InputNode,
  output: OutputNode,
  text: TextNode,
  llm: LLMNode,
  transform: TransformNode,
  filter: FilterNode,
  aggregate: AggregateNode,
};

let nodeId = 0;
const getId = () => `node_${nodeId++}`;

const PipelineCanvas = () => {
  const [nodes, setNodes, onNodesChange] = useNodesState([]);
  const [edges, setEdges, onEdgesChange] = useEdgesState([]);
  const [selectedNode, setSelectedNode] = useState<Node | null>(null);
  const [isConfigDialogOpen, setIsConfigDialogOpen] = useState(false);
  const [isWorkflowDialogOpen, setIsWorkflowDialogOpen] = useState(false);
  const [workflowMode, setWorkflowMode] = useState<'save' | 'load'>('save');
  const { toast } = useToast();

  const onConnect = useCallback(
    (params: Connection | Edge) => setEdges((eds) => addEdge(params, eds)),
    [setEdges]
  );

  const onAddNode = useCallback(
    (type: string, label: string) => {
      const newNode: Node = {
        id: getId(),
        type,
        position: { x: Math.random() * 400 + 100, y: Math.random() * 400 + 100 },
        data: { label },
      };
      setNodes((nds) => [...nds, newNode]);
    },
    [setNodes]
  );

  const validateDAG = useCallback((): boolean => {
    const adjList = new Map<string, string[]>();
    nodes.forEach(node => adjList.set(node.id, []));
    
    edges.forEach(edge => {
      const sources = adjList.get(edge.source) || [];
      sources.push(edge.target);
      adjList.set(edge.source, sources);
    });

    const visited = new Set<string>();
    const recStack = new Set<string>();

    const hasCycle = (nodeId: string): boolean => {
      if (recStack.has(nodeId)) return true;
      if (visited.has(nodeId)) return false;

      visited.add(nodeId);
      recStack.add(nodeId);

      const neighbors = adjList.get(nodeId) || [];
      for (const neighbor of neighbors) {
        if (hasCycle(neighbor)) return true;
      }

      recStack.delete(nodeId);
      return false;
    };

    for (const node of nodes) {
      if (hasCycle(node.id)) return false;
    }

    return true;
  }, [nodes, edges]);

  const onSubmit = useCallback(async () => {
    try {
      const result = await submitPipeline(nodes, edges);
      
      toast({
        title: "Pipeline Submitted ✓",
        description: (
          <div className="space-y-1">
            <p><strong>Number of Nodes:</strong> {result.num_nodes}</p>
            <p><strong>Number of Edges:</strong> {result.num_edges}</p>
            <p><strong>Is DAG:</strong> {result.is_dag ? '✓ Yes' : '✗ No'}</p>
          </div>
        ),
        variant: result.is_dag ? "default" : "destructive",
        duration: 5000,
      });
      
      alert(
        `Number of Nodes: ${result.num_nodes}\n` +
        `Number of Edges: ${result.num_edges}\n` +
        `Is DAG: ${result.is_dag}`
      );
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to submit pipeline. Make sure the backend is running.",
        variant: "destructive",
        duration: 5000,
      });
      console.error('Submit error:', error);
    }
  }, [nodes, edges, toast]);

  const onNodeDoubleClick: NodeMouseHandler = useCallback((event, node) => {
    setSelectedNode(node);
    setIsConfigDialogOpen(true);
  }, []);

  const handleNodeConfigSave = useCallback((nodeId: string, data: any) => {
    setNodes((nds) =>
      nds.map((node) =>
        node.id === nodeId ? { ...node, data } : node
      )
    );
  }, [setNodes]);

  const handleSaveWorkflow = useCallback(() => {
    setWorkflowMode('save');
    setIsWorkflowDialogOpen(true);
  }, []);

  const handleLoadWorkflow = useCallback(() => {
    setWorkflowMode('load');
    setIsWorkflowDialogOpen(true);
  }, []);

  const handleWorkflowLoad = useCallback((loadedNodes: Node[], loadedEdges: Edge[]) => {
    setNodes(loadedNodes);
    setEdges(loadedEdges);
    toast({
      title: "Workflow Loaded",
      description: "Your workflow has been loaded successfully.",
    });
  }, [setNodes, setEdges, toast]);

  return (
    <div className="w-full h-screen bg-gradient-bg">
      <Toolbar 
        onAddNode={onAddNode} 
        onSubmit={onSubmit}
        onSaveWorkflow={handleSaveWorkflow}
        onLoadWorkflow={handleLoadWorkflow}
      />
      <ReactFlow
        nodes={nodes}
        edges={edges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        onConnect={onConnect}
        onNodeDoubleClick={onNodeDoubleClick}
        nodeTypes={nodeTypes}
        fitView
      >
        <Background />
        <Controls />
        <MiniMap
          nodeColor={(node) => {
            const colors: Record<string, string> = {
              input: '#22c55e',
              output: '#ef4444',
              text: '#3b82f6',
              llm: '#a855f7',
              transform: '#f59e0b',
              filter: '#f97316',
              aggregate: '#10b981',
            };
            return colors[node.type || 'default'] || '#6b7280';
          }}
        />
      </ReactFlow>

      <NodeConfigDialog
        isOpen={isConfigDialogOpen}
        onClose={() => setIsConfigDialogOpen(false)}
        node={selectedNode}
        onSave={handleNodeConfigSave}
      />

      <WorkflowDialog
        isOpen={isWorkflowDialogOpen}
        onClose={() => setIsWorkflowDialogOpen(false)}
        mode={workflowMode}
        currentNodes={nodes}
        currentEdges={edges}
        onLoad={handleWorkflowLoad}
      />
    </div>
  );
};

export default PipelineCanvas;
