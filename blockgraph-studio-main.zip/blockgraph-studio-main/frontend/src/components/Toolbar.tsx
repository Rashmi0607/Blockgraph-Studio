import { Database, Save, Type, Brain, Wand2, Filter, Layers, FolderOpen, Download } from 'lucide-react';
import { Button } from './ui/button';

interface ToolbarProps {
  onAddNode: (type: string, label: string) => void;
  onSubmit: () => void;
  onSaveWorkflow: () => void;
  onLoadWorkflow: () => void;
}

const nodeTypes = [
  { type: 'input', label: 'Input', icon: Database, color: 'border-node-input' },
  { type: 'output', label: 'Output', icon: Save, color: 'border-node-output' },
  { type: 'text', label: 'Text', icon: Type, color: 'border-node-text' },
  { type: 'llm', label: 'LLM', icon: Brain, color: 'border-node-llm' },
  { type: 'transform', label: 'Transform', icon: Wand2, color: 'border-node-transform' },
  { type: 'filter', label: 'Filter', icon: Filter, color: 'border-node-filter' },
  { type: 'aggregate', label: 'Aggregate', icon: Layers, color: 'border-node-aggregate' },
];

const Toolbar = ({ onAddNode, onSubmit, onSaveWorkflow, onLoadWorkflow }: ToolbarProps) => {
  return (
    <div className="absolute top-4 left-4 z-10 bg-card rounded-lg shadow-node border border-border p-4">
      <h3 className="text-sm font-semibold mb-3 text-foreground">Add Nodes</h3>
      <div className="flex flex-col gap-2">
        {nodeTypes.map((node) => (
          <Button
            key={node.type}
            variant="secondary"
            size="sm"
            onClick={() => onAddNode(node.type, node.label)}
            className={`justify-start gap-2 border-l-2 ${node.color}`}
          >
            <node.icon className="w-4 h-4" />
            {node.label}
          </Button>
        ))}
      </div>
      <div className="mt-4 space-y-2">
        <Button
          onClick={onSaveWorkflow}
          variant="outline"
          className="w-full gap-2"
          size="sm"
        >
          <Download className="w-4 h-4" />
          Save Workflow
        </Button>
        <Button
          onClick={onLoadWorkflow}
          variant="outline"
          className="w-full gap-2"
          size="sm"
        >
          <FolderOpen className="w-4 h-4" />
          Load Workflow
        </Button>
        <Button
          onClick={onSubmit}
          className="w-full bg-gradient-primary hover:opacity-90"
          size="sm"
        >
          Submit Pipeline
        </Button>
      </div>
    </div>
  );
};

export default Toolbar;
