import { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from './ui/dialog';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';

interface NodeConfigDialogProps {
  isOpen: boolean;
  onClose: () => void;
  node: any;
  onSave: (nodeId: string, data: any) => void;
}

const NodeConfigDialog = ({ isOpen, onClose, node, onSave }: NodeConfigDialogProps) => {
  const [label, setLabel] = useState('');
  const [content, setContent] = useState('');

  useEffect(() => {
    if (node) {
      setLabel(node.data.label || '');
      setContent(node.data.content || '');
    }
  }, [node]);

  const handleSave = () => {
    if (node) {
      onSave(node.id, {
        ...node.data,
        label,
        content,
      });
    }
    onClose();
  };

  if (!node) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Configure {node.type} Node</DialogTitle>
          <DialogDescription>
            Update the node's label and content
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid gap-2">
            <Label htmlFor="label">Label</Label>
            <Input
              id="label"
              value={label}
              onChange={(e) => setLabel(e.target.value)}
              placeholder="Enter node label"
            />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="content">Content</Label>
            <Textarea
              id="content"
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="Enter node content (use {{variable}} for dynamic inputs)"
              rows={5}
            />
          </div>
        </div>
        <div className="flex justify-end gap-2">
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={handleSave}>
            Save Changes
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default NodeConfigDialog;
