import PipelineCanvas from '@/components/PipelineCanvas';

const Index = () => {
  return <PipelineCanvas />;
};

export default Index;
