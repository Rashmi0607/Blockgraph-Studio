# VectorShift Pipeline Editor - Frontend

A visual node-based pipeline editor built with React, TypeScript, and React Flow.

## Setup

```bash
# Install dependencies
npm install

# Start development server
npm run dev
```

The frontend runs at: `http://localhost:8080`

## Technologies

- **React** - UI framework
- **TypeScript** - Type safety
- **React Flow** - Node-based canvas
- **TailwindCSS** - Styling
- **shadcn-ui** - UI components
- **Vite** - Build tool

## Features

- Drag-and-drop node creation
- Visual edge connections
- Dynamic text node with variable detection
- Pipeline validation with backend integration
- Modern, responsive design
